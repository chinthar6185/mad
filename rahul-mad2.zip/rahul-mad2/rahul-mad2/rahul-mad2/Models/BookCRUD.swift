//
//  BookCRUD.swift
//  Assignment 2
//
//  Created by rahul vuppula on 10/21/23.
//

import UIKit
import CoreData
class BookCRUD: NSObject {
     static func create(newTitle:String, newAuthor:String, newSubName:String, newDueDate:Date) {
        //Get the managed context context from AppDelegate
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            //Create a new empty record.
            let bookEntity = NSEntityDescription.entity(forEntityName: "Book", in: managedContext)!
            //Fill the new record with values
            let book = NSManagedObject(entity: bookEntity, insertInto: managedContext)
            book.setValue(newTitle, forKeyPath: "title")
            book.setValue(newAuthor, forKey: "author")
            book.setValue(newSubName, forKey: "subjectName")
            book.setValue(newDueDate, forKey: "dueDate")
            do {
                //Save the managed object context
                try managedContext.save()
            } catch let error as NSError {
                print("Could not create the new record! \(error), \(error.userInfo)")
            }
        }
    }
    
    static func read(title:String) -> String? {
        //Get the managed context context from AppDelegate
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            
            //Prepare the request of type NSFetchRequest  for the entity (SELECT * FROM)
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Book")
            //Add a contition to the fetch request (WHERE)
            fetchRequest.predicate = NSPredicate(format: "title = %@", title)
            //Add a sorting preference (ORDER BY)
            fetchRequest.sortDescriptors = [NSSortDescriptor.init(key: "dueDate", ascending: false)]
            do {
                //Execute the fetch request
                let result = try managedContext.fetch(fetchRequest)
                if result.count > 0 {
                    let randNum = Int.random(in: 0 ..< result.count)
                    let record = result[randNum] as! NSManagedObject
                    let word = record.value(forKey: "title") as! String
                    return word
                }
            } catch let error as NSError {
                print("Could not fetch the record! \(error), \(error.userInfo)")
            }
        }
        return nil
    }
    
    static func delete(oldTitle:String) {
        //Get the managed context context from AppDelegate
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            
            //Prepare a fetch request for the record to delete
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Book")
            fetchRequest.predicate = NSPredicate(format: "title = %@", oldTitle)
            
            do {
                //Fetch the record to delete
                let test = try managedContext.fetch(fetchRequest)
                
                //Delete the record
                let objectToDelete = test[0] as! NSManagedObject
                managedContext.delete(objectToDelete)
                do {
                    //Save the managed object context
                    try managedContext.save()
                }
                catch let error as NSError {
                    print("Could not delete the record! \(error), \(error.userInfo)")
                }
            }
            catch let error as NSError {
                print("Could not find the record to delete! \(error), \(error.userInfo)")
            }
        }
    }
    
    static func update(oldTitle:String, newTitle:String) {
        //Get the managed context context from AppDelegate
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            
            //Prepare a fetch request for the record to update
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Book")
            fetchRequest.predicate = NSPredicate(format: "title = %@", oldTitle)
            
            do{
                //Fetch the record to update
                let test = try managedContext.fetch(fetchRequest)
                //Update the record
                let objectToUpdate = test[0] as! NSManagedObject
                objectToUpdate.setValue(newTitle, forKey: "title")
                do{
                    //Save the managed object context
                    try managedContext.save()
                }
                catch let error as NSError {
                    print("Could not update the record! \(error), \(error.userInfo)")
                }
            }
            catch let error as NSError {
                print("Could not find the record to update! \(error), \(error.userInfo)")
            }
        }
    }
}
