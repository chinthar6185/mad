//
//  ViewController.swift
//  Assignment 2
//
//  Created by rahul on 10/21/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

