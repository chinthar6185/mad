//
//  BookTableViewCell.swift
//  Assignment 2
//
//  Created by rahul vuppula on 10/22/23.
//

import UIKit

class BookTableViewCell: UITableViewCell {

    @IBOutlet weak var dueDateLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
