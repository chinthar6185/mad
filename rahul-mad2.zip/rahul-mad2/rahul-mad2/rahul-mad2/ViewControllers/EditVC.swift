//
//  EditVC.swift
//  Assignment 2
//
//  Created by rahul on 10/31/23.
//

import UIKit
import CoreData
class EditVC: UIViewController {
    var bookobj:Book?
    
    @IBOutlet weak var newdatepkr: UIDatePicker!
    @IBOutlet weak var subjectname: UITextField!
    @IBOutlet weak var newauthor: UITextField!
    @IBOutlet weak var newtitle: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func doneBtnAction(_ sender: Any) {
        bookobj?.title = newtitle.text
        bookobj?.author = newauthor.text
        bookobj?.subjectName = subjectname.text
        bookobj?.dueDate=newdatepkr.date
        
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            
            do {
                let context = appDelegate.persistentContainer.viewContext
                try context.save()
                if let presentingVC = presentingViewController as? CheckBookDetailsVC {
                    presentingVC.book?.author=newauthor.text
                    presentingVC.book?.title=newtitle.text
                    presentingVC.book?.subjectName=subjectname.text
                    presentingVC.book?.dueDate=newdatepkr.date
                   }
                //Dismiss the EditVC to return to the previous view controller
                displaySuccessMessage("Updated Successfully")
            } catch {
                print("Error updating book: \(error)")
            }
        }
    }
    
    
    func displaySuccessMessage(_ message: String) {
        // Create and display a success message to the user
        let alertController = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        present(alertController, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
