//
//  BookView.swift
//  Assignment 2
//
//  Created by rahul on 10/22/23.
//

import UIKit
import CoreData


class BookView: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var books: [Book] = []
    @IBOutlet weak var addBookBtn: UIButton!
    @IBOutlet weak var bookTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // deleteAllBooks()
        bookTable.reloadData()
        fetchBooks()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return books.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "BookCell", for: indexPath) as! BookTableViewCell
        let book = books[indexPath.row]
        cell.titleLbl?.text = book.title
        if let dueDate = book.dueDate {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM dd, yyyy"  // Define your desired date format

            let formattedDate = dateFormatter.string(from: dueDate)
            cell.dueDateLbl.text = formattedDate
        } else {
            cell.dueDateLbl.text = "No Due Date"  // Handle the case when dueDate is nil
        }
        return cell
    }
    
    /*func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        /*if let vc = storyboard?.instantiateViewController(withIdentifier: "CheckBookDetailsVC") as? CheckBookDetailsVC{
            self.navigationController?.pushViewController(vc, animated: true)
            vc.book?=books[indexPath.row]
        }*/
    }*/
    
    func fetchBooks() {
        //let context = AppDelegate().persistentContainer.viewContext
        //let fetchRequest: NSFetchRequest<Book> = Book.fetchRequest()
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            let fetchRequest: NSFetchRequest<Book> = Book.fetchRequest()
            let sortDescriptor = NSSortDescriptor(key: "dueDate", ascending: false)
                fetchRequest.sortDescriptors = [sortDescriptor]
            do {
                books = try managedContext.fetch(fetchRequest)
                bookTable.reloadData()
            } catch {
                print("Error fetching data: \(error.localizedDescription)")
            }
        }
        
    }
    

    func deleteAllBooks() {
        let context = AppDelegate().persistentContainer.viewContext

        // Fetch all books
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "Book")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try context.execute(batchDeleteRequest)
            // All data deleted successfully
        } catch {
            // Handle the error
            print("Error deleting all data: \(error)")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.bookTable.reloadData()
        fetchBooks()
        self.bookTable.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.bookTable.reloadData()
        fetchBooks()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "CheckBookDetailsVC",
               let indexPath = bookTable.indexPathForSelectedRow,
               let destinationVC = segue.destination as? CheckBookDetailsVC {
               
               let selectedBook = books[indexPath.row]
               destinationVC.book = selectedBook
            }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

