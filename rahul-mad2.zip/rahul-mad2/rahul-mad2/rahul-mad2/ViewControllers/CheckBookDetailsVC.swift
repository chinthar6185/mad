//
//  CheckBookDetailsVC.swift
//  Assignment 2
//
//  Created by rahul vuppula on 10/29/23.
//

import UIKit
import CoreData
class CheckBookDetailsVC: UIViewController {
    var book: Book?
    @IBOutlet weak var deleteBtn: UIButton!
    @IBOutlet weak var updateBtn: UIButton!
    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var sublbl: UILabel!
    @IBOutlet weak var authorlbl: UILabel!
    @IBOutlet weak var titlelbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        titlelbl.text=book?.title
        authorlbl.text=book?.author
        sublbl.text=book?.subjectName
        if let dueDate = book?.dueDate {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMM dd, yyyy"  // Define your desired date format

            let formattedDate = dateFormatter.string(from: dueDate)
            datelbl.text = formattedDate
        } else {
            datelbl.text = "No Due Date"  // Handle the case when dueDate is nil
        }
        if let presentingVC = presentingViewController as? BookView {
            presentingVC.fetchBooks()
           }
    }
    
    @IBAction func deleteBtnAction(_ sender: Any) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let context = appDelegate.persistentContainer.viewContext
            if let book = book {
                context.delete(book)
                
                do {
                    try context.save()
                    if let presentingVC = presentingViewController as? BookView {
                        presentingVC.fetchBooks()
                       }
                    displaySuccessMessage("Deleted Successfully")
                    // Book deleted successfully, navigate back to the previous view controller
                    navigationController?.popViewController(animated: true)
                } catch {
                    print("Error deleting book: \(error)")
                }
            }
        }
        
        func displaySuccessMessage(_ message: String) {
            // Create and display a success message to the user
            let alertController = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                self.dismiss(animated: true, completion: nil)
            }))
            present(alertController, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func updateBtnAction(_ sender: Any) {
        performSegue(withIdentifier: "CheckToEdit", sender: self)
        if let presentingVC = presentingViewController as? BookView {
            presentingVC.fetchBooks()
           }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "CheckToEdit", let editVC = segue.destination as? EditVC {
            // Pass the book details to the EditVC
            editVC.bookobj = book
            if let presentingVC = presentingViewController as? BookView {
                presentingVC.fetchBooks()
            }
        }
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
