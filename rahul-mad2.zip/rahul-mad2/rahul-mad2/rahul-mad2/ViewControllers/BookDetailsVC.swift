//
//  BookDetailsVC.swift
//  Assignment 2
//
//  Created by rahul on 10/27/23.
//

import UIKit
import CoreData
protocol DataSaveDelegate: AnyObject {
    func didSaveData()
}

class BookDetailsVC: UIViewController {

    weak var delegate:DataSaveDelegate?
    @IBOutlet weak var dueDatepkr: UIDatePicker!
    @IBOutlet weak var vStack: UIStackView!
    @IBOutlet weak var titleTxt: UITextField!
    @IBOutlet weak var subjectTxt: UITextField!
    @IBOutlet weak var authorTxt: UITextField!
    @IBOutlet weak var submitBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitBtnAction(_ sender: Any) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate{
            let context = appDelegate.persistentContainer.viewContext
            let newBook = Book(context: context)
            newBook.title = titleTxt.text
            newBook.author = authorTxt.text
            newBook.subjectName = subjectTxt.text
            newBook.dueDate = dueDatepkr.date
            do{
                try context.save()
                delegate?.didSaveData()
                if let presentingVC = presentingViewController as? BookView {
                    presentingVC.fetchBooks()
                   }
                displaySuccessMessage("Book saved successfully!")
                authorTxt.text = ""
                titleTxt.text = ""
                subjectTxt.text=""
            } catch {
                // Handle the error
                displayErrorMessage("Error saving data: \(error.localizedDescription)")
            }
        }
    }
    
    func displaySuccessMessage(_ message: String) {
        // Create and display a success message to the user
        let alertController = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        present(alertController, animated: true, completion: nil)
    }
    
    func displayErrorMessage(_ message: String) {
        // Create and display an error message to the user
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.dismiss(animated: true, completion: nil)
        }))
        present(alertController, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
